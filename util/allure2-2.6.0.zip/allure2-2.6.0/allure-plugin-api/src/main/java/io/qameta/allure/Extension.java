package io.qameta.allure;

/**
 * Marker interface for all the extension points.
 *
 * @since 2.0
 */
public interface Extension {
}
