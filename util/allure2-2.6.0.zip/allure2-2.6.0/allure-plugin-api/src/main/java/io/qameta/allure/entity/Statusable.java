package io.qameta.allure.entity;

/**
 * @author Dmitry Baev baev@qameta.io
 * Date: 31.01.16
 */
public interface Statusable {

    Status getStatus();

}
