export default function isDef(variable) {
    return (variable || typeof variable === 'number');
}
