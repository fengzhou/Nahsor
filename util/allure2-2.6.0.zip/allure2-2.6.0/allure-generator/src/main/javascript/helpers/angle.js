import {SafeString} from 'handlebars/runtime';


export default function() {
    return new SafeString('<span class="angle fa fa-angle-right fa-fw fa-lg"></span>');
}