import LoadBehavior from './LoadBehavior';
import TooltipBehavior from './TooltipBehavior';
import ClipboardBehavior from './ClipboardBehavior';

export {LoadBehavior, TooltipBehavior, ClipboardBehavior};
