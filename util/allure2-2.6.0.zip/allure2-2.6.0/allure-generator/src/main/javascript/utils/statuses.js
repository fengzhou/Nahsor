export const values = ['failed', 'broken', 'passed', 'skipped', 'unknown'];
