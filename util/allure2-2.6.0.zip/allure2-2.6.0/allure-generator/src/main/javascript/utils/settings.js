import {getGlobalSettings} from './settingsFactory';

const globalSettings = getGlobalSettings();
export default globalSettings;
