import SeverityChartView from './SeverityWidgetView';

allure.api.addWidget('graph', 'severity', SeverityChartView);
