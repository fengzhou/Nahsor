import DescriptionView from './DescriptionView';

allure.api.addTestResultBlock(DescriptionView, {position: 'before'});
