import LinksView from './LinksView';

allure.api.addTestResultBlock(LinksView, {position: 'before'});
