import OwnerView from './OwnerView';

allure.api.addTestResultBlock(OwnerView, {position: 'before'});