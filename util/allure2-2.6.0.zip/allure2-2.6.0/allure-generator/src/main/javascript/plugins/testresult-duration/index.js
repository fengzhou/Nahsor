import DurationView from './DurationView';

allure.api.addTestResultBlock(DurationView, {position: 'tag'});
