import SummaryWidgetView from './SummaryWidgetView';

allure.api.addWidget('widgets', 'summary', SummaryWidgetView);