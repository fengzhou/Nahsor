import HistoryView from './HistoryView';

allure.api.addTestResultTab('history', 'testResult.history.name', HistoryView);