import {View} from 'backbone.marionette';
import template from './LaunchesWidgetView.hbs';

class LaunchesWidgetView extends View {
    template = template;
}

export default LaunchesWidgetView;